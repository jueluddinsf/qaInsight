import type { NextApiRequest, NextApiResponse } from 'next';

import { pipeline } from 'node:stream/promises';
import { PassThrough } from 'node:stream';
import { randomUUID } from 'node:crypto';

import Busboy from 'busboy';

import { service } from '@/app/lib/service';
import { DEFAULT_STREAM_CHUNK_SIZE } from '@/app/lib/storage/constants';
import { withError } from '@/app/lib/withError';

export const config = { api: { bodyParser: false } };

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'PUT') {
    res.setHeader('Allow', 'PUT');

    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const resultID = randomUUID();
  const fileName = `${resultID}.zip`;

  const contentLength = (req.query['fileContentLength'] as string) ?? '';

  if (contentLength || parseInt(contentLength, 10)) {
    console.log(
      `[upload] fileContentLength query parameter is provided for result ${resultID}, using presigned URL flow`,
    );
  }
  // if there is fileContentLength query parameter we can use presigned URL for direct upload
  const presignedUrl = contentLength ? await service.getPresignedUrl(fileName) : '';

  const resultDetails: Record<string, string> = {};
  let fileSize = 0;

  const filePassThrough = new PassThrough({
    highWaterMark: DEFAULT_STREAM_CHUNK_SIZE,
  });

  const bb = Busboy({
    headers: req.headers,
    limits: {
      files: 1,
    },
    highWaterMark: DEFAULT_STREAM_CHUNK_SIZE,
    fileHwm: DEFAULT_STREAM_CHUNK_SIZE,
  });

  let saveResultPromise: Promise<void>;

  const uploadPromise = new Promise<void>((resolve, reject) => {
    let fileReceived = false;

    const onAborted = () => {
      if (!filePassThrough.destroyed) {
        filePassThrough.destroy(new Error('Client aborted connection'));
      }
    };

    req.on('aborted', onAborted);
    req.on('close', onAborted);

    bb.on('file', (_, fileStream) => {
      fileReceived = true;

      saveResultPromise = service
        .saveResult(fileName, filePassThrough, presignedUrl, contentLength)
        .catch((error: Error) => {
          reject(error);
        });

      pipeline(
        fileStream.on('data', (chunk: Buffer) => {
          fileSize += chunk.length;
        }),
        filePassThrough,
      ).catch((e) => {
        filePassThrough.destroy(e);
        reject(e);
      });
    });

    bb.on('field', (name, val) => {
      resultDetails[name] = val;
    });

    bb.on('error', (error: Error) => {
      reject(error);
    });

    bb.on('finish', async () => {
      if (!fileReceived) {
        reject(new Error('No file received'));

        return;
      }

      if (saveResultPromise) {
        const { error } = await withError(saveResultPromise);

        if (error) {
          reject(error);
        }

        if (contentLength) {
          const expected = parseInt(contentLength, 10);

          if (Number.isFinite(expected) && expected > 0 && fileSize !== expected) {
            reject(new Error(`Size mismatch: received ${fileSize} bytes, expected ${expected} bytes`));

            return;
          }
        }

        resolve();
      }
    });
  });

  const { error: streamPipelineError } = await withError(pipeline(req, bb));

  if (streamPipelineError) {
    console.error('Error processing request:', streamPipelineError);

    return;
  }

  const { error: uploadError } = await withError(uploadPromise);

  if (uploadError) {
    if (!filePassThrough.destroyed) {
      filePassThrough.destroy();
    }

    res.status(400).json({ error: `upload result failed: ${uploadError.message}` });

    return;
  }

  const { result: uploadResult, error: uploadResultDetailsError } = await withError(
    service.saveResultDetails(resultID!, resultDetails, fileSize),
  );

  if (uploadResultDetailsError) {
    res.status(400).json({ error: `upload result details failed: ${uploadResultDetailsError.message}` });
    await service.deleteResults([resultID!]);

    return;
  }

  let generatedReport = null;

  if (resultDetails.shardCurrent && resultDetails.shardTotal && resultDetails.triggerReportGeneration === 'true') {
    const { result: results, error: resultsError } = await withError(
      service.getResults({
        testRun: resultDetails.testRun,
      }),
    );

    if (resultsError) {
      return res.status(500).json({ error: `failed to generate report: ${resultsError.message}` });
    }

    const testRunResults = results?.results.filter(
      (result) =>
        result.testRun === resultDetails.testRun &&
        (resultDetails.project ? result.project === resultDetails.project : true),
    );

    console.log(`found ${testRunResults?.length} results for the test run ${resultDetails.testRun}`);

    // Checking if all shards are uploaded
    if (testRunResults?.length === parseInt(resultDetails.shardTotal)) {
      const ids = testRunResults.map((result) => result.resultID);

      console.log('triggerReportGeneration for', resultDetails.testRun, ids);
      const { result, error } = await withError(
        service.generateReport(ids, {
          project: resultDetails.project,
          testRun: resultDetails.testRun,
          playwrightVersion: resultDetails.playwrightVersion,
        }),
      );

      if (error) {
        return res.status(500).json({ error: `failed to generate report: ${error.message}` });
      }

      generatedReport = result;
    }
  }

  return res.status(200).json({
    message: 'Success',
    data: { ...uploadResult, generatedReport },
  });
}
